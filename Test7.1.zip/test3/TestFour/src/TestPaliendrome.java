import org.junit.Test;
import org.junit.Assert;
public class TestPaliendrome {
	
	@Test
	public void firstTest()
	{
		 PaliendromeCheck paliendrome=new PaliendromeCheck();
		 String testArray="LaLu";
	    int check=paliendrome.checkPaliendrome(testArray);
		Assert.assertEquals(0,check);
	}
	}





