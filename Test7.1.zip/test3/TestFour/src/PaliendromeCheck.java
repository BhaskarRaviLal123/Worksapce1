
public class PaliendromeCheck {

		public int checkPaliendrome(String arraypal) 
		{	
				String reversethesentence = "";
			
				for (int i = arraypal.length() - 1; i >= 0; i--) 
				{
					reversethesentence += arraypal.charAt(i);
				}
				if (arraypal.equalsIgnoreCase(reversethesentence)) 
				{
					System.out.println("Yes the entered string is paliendrome");
					return 0;
				} 
				else 
				{
					System.out.println("No it is not paliendrome");
				}
			return 1;

		}
	}
