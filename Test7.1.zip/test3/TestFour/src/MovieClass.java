
public class MovieClass {

	String movieName;
	String language;
	String certification;
	public void setmovieDetails(String movie,String languages,String certifications)
	{
		movieName = movie;
		language = languages;
		certification = certifications;
		
	}
	
	public void displaymovieDetails()
	{
		System.out.println(movieName+" "+language+" "+certification);
	}
}
