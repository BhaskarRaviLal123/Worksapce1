import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
public class TestMovieFile {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
	   InputStreamReader reading =  new InputStreamReader(System.in);
	   BufferedReader bufferedreader = new BufferedReader(reading);
	   HashMap movie =  new HashMap();
//	   int i = 1;
	   System.out.println("Enter Add to add movie details and enter Search to search the movie details");
	   String yourchoice = bufferedreader.readLine();
	   if (yourchoice.equalsIgnoreCase("Add"))
	    while(true)
	    	{
		
	    	FileWriter writefile = new FileWriter("movies.txt", true);
	    	BufferedWriter writer = new BufferedWriter(writefile);
	    	System.out.println("Enter the movie name");
	    	String mname = bufferedreader .readLine();
	    	System.out.println("Enter the movie Language");
	    	String mlang = bufferedreader .readLine();
	    	System.out.println("Enter the certification");
	    	String mcert =bufferedreader .readLine();
	   
	    	writer.write(mname+","+ mlang +","+mcert);
	    	writer.newLine();
	    	writer.close();
	    	System.out.println("Enter zero to exit ");
	    	yourchoice = bufferedreader.readLine();
	    	if(yourchoice.equalsIgnoreCase("zero"));
	    	{
	    		break;
	    		
	    	}
	   }
	    	 if(yourchoice.equalsIgnoreCase("Search"));
	    	{
	    		
	    		FileReader fileReading = new FileReader("movies.txt");
	    		BufferedReader buffRead = new BufferedReader(fileReading);
	    		String line = buffRead.readLine();//1
	    		for (int i = 0; line!=null; i++)
	    		{
	    		String arry[] = line.split(",");
	    		String name1 = arry[0];
	    		String langm = arry[1];
	    		String certm = arry[2];
	    	
	    		
	    		 MovieClass movieclass  = new MovieClass();
	    		 movieclass.setmovieDetails(name1, langm, certm);
	    		 movie.put(i,movieclass);
	    	
	    	    line = buffRead.readLine();//2nd
	    		}
	    	    while(true)
			  {
	    	    System.out.println("1.Dsiplay the title of movies");
	    	    System.out.println("2.Display the movie details in particular language");
	    	    System.out.println("3.Dsiplay all movies with A certification");
	    	    System.out.println("4.Dsiaply all movies with U certification");
	    	    System.out.println("5.Quit");
	    	    int options = Integer.parseInt(bufferedreader.readLine());
	    	    switch (options) {
	    	    case 1: 
	    	    fileReading= new FileReader("movies.txt");
	    	    buffRead = new BufferedReader(fileReading);
	    	    line = buffRead.readLine();
	    	    while (line != null) {
	    	    System.out.println(arry[0]);
	    	    line = buffRead.readLine();
	    	    }
	    	    buffRead.close();
	    	    fileReading.close();
	    	    break;
	    	    case 2:
	    	    	System.out.println("Enter the language");
	    	    	String languages = bufferedreader.readLine();
	    	    	Set keys = movie.keySet();
	    	    	Iterator it = keys.iterator();
	    	    	while (it.hasNext()) {
	    	    	int k = (Integer) it.next();
	    	    	 MovieClass mv = ( MovieClass)movie.get(k);
	    	    	if(languages.equalsIgnoreCase(langm)){
	    	    	
	    	    		{ 
	    	    			i++;
	    	    			movieclass.displaymovieDetails();
	    	    		}
	    	    	}
	    	    	else {
	    	    		System.out.println("No such information avilable in this option");
	    	    		}
	    	    	}
	    	    	break;
	    	    case 3:
	    	    	
	    	    	System.out.println("Enter the certification");
	    	    	String certy= bufferedreader.readLine();
	    	    	
	    	    	if(certy.equalsIgnoreCase(certm))
	    	    	{
	    	    		System.out.println(movieclass.movieName);
	    	    	}
	    	    	else {
	    	    		System.out.println("No such information avilable in this option");
	    	    		}
	    	    	
	    	    	break;
	    	    case 4:
	    	    	
	    	    	System.out.println("Enter the certification");
	    	    	String certy2= bufferedreader.readLine();
	    	    	
	    	    	if(certy2.equalsIgnoreCase(certm))
	    	    	{
	    	    		System.out.println(movieclass.movieName);
	    	    	}
	    	    	else {
	    	    		System.out
	    	    		.println("No such information avilable in this option");
	    	    		}
	    	    	
	    	    	break;
	    	    	
	    	    case 5:
	    	    	System.out.println("Thank you for checking movie details.");
	    	    	System.exit(0);
	    	    }
	    	}
	    }
	 }
  }
}
	    	

	


