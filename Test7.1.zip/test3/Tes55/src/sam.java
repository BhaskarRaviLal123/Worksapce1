


public class sam {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	

	}
}
	



