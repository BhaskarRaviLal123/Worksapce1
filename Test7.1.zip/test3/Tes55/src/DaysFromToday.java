import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;


public class DaysFromToday {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		
		BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the number to check the day");
		int day=Integer.parseInt(reader.readLine());
		DateFormat dateFormat = new SimpleDateFormat("EEEE");//Constructs a simple date format for the default locale
		Calendar calender = Calendar.getInstance();//retruns calender using the default locale
		calender.add(Calendar.DATE, day);//Add or subtract the specified time  
	    System.out.println("AFTER 10 DAYS THE DAY WILL BE: " + dateFormat.format(calender.getTime()));
	    System.out.println("The date will be :"+calender.getTime());+

		
	}

}
