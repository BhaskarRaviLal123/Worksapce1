
public class Course {
	String courseId;
	String courseName;

	public void setcourseDeatils(String a,String b)
	{
		courseId = a;
		courseName = b;
	}
	public void printcourseDetails()
	{
		System.out.println("The course code is "+courseId );
		System.out.println("The course name is "+courseName );
	}
}
