import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;


public class TestCourse {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		InputStreamReader inputreader=new InputStreamReader(System.in);

		BufferedReader bufferreader=new BufferedReader(inputreader);

		HashMap courses=new HashMap();

		
		for(int i=0;i<2;i++)

		{
				
			System.out.println("Enter the course Id");
			String id = bufferreader.readLine();
			System.out.println("Enter the course Name");
			String cname = bufferreader.readLine();
			Course cs=new Course();
			cs.setcourseDeatils(id, cname);
			courses.put(id,cname);
			
		}
		System.out.println(courses);		
		System.out.println("Please start querrying me");
		System.out.println("Enter the course id to search the course name:");
		Set keys=courses.keySet();

		Iterator it=keys.iterator();
	
		String idsearch=bufferreader.readLine();

		while(it.hasNext())

		{

		String id1=(String)it.next();

		String val=(String)courses.get(id1);
		if (id1.equals(id1))
			System.out.println(val);

//		if(val.courseId.equalsIgnoreCase(idsearch))
//
//		{
//
//				System.out.println("The course name for the course id is "+val.courseName);
//
//		}
//		else
//		{
//			System.out.println("I dont have any course with such id");
//		}
//
//		}

		 

		}

	}
}


