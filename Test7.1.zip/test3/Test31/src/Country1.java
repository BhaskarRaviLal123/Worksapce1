import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Country1 {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		InputStreamReader ip = new InputStreamReader(System.in);
		BufferedReader b = new BufferedReader(ip);
		String co[]=new String[10];
	
	
		for(int i =1;i<=2;i++)
		{
			//String cont = b.readLine();
			//System.out.println("Enter a country");
			System.out.println("Enter a country");
			String ty = b.readLine();
		
			co[i]=ty;
			for(int j =1;j<=2;j++)
			{
				System.out.println("enter the capital");
				String cap = b.readLine();
				
				co[j]=cap;
			}
		//	if(ty.equalsIgnoreCase(cont))
			//{
				
				//System.out.println("The counrty is available " +ty);
			}
		//else
		
			//	System.out.println("The country is not found currently");
		
			
		//}
		

		
		}
	}


