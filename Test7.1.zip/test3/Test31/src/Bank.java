
public class Bank extends Exception{
	static String nameOfTheCustomer = "Rahul";
	static int accountNumber = 1133;
	static double balanceAmount = 1000;
	
	public static void bankdet(String n,int a,double ab)
	{
		nameOfTheCustomer = n;
		accountNumber = a;
		 balanceAmount = ab;
	}
	
	
}
