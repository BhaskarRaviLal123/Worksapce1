import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class TestBank {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		InputStreamReader is = new InputStreamReader(System.in);
		BufferedReader b = new BufferedReader(is);
		int j = 0;
		System.out.println("1:Deposit Money");
		System.out.println("2:Withdraw Money");
		System.out.println("3:View Account balance");
		System.out.println("4:quit");
		while(true)
		{
			j = Integer.parseInt(b.readLine());
			switch(j)
			{
			case 1:
				System.out.println("Enter the money to deposit");
				int d  = b.read();
				Bank e = new Bank();
				e.balanceAmount =  1000;
				double tot = e.balanceAmount+d;
				System.out.println(tot);
				break;
			case 2: 
				System.out.println("Enter the amount to withdraw");
				int w = b.read();
				Bank p = new Bank();
				int with = 0;
				with = 1000-w;
				break;
			case 3:
				System.out.println("Account details");
				Bank nk = new Bank();
				System.out.println("The name of the account holder :"+nk.nameOfTheCustomer);
				System.out.println("The account number of holder :" +nk.accountNumber);
				
				System.out.println("The balance amount in bank :"+nk.balanceAmount);
				break;
			case 4:
				System.out.println("Thank you for using bank");
			    System.exit(0);
				
		}

	}

	}}
