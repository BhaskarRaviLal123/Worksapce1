import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;


public class Book12 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		InputStreamReader is = new InputStreamReader(System.in);
		BufferedReader b = new BufferedReader(is);
		System.out.println("1:Add a book");
		System.out.println("2:View all Books");
		System.out.println("3:Exit");
		int c =0;
		while(true)
		{
			System.out.println("Enter your choice");
			try{
			c =Integer.parseInt(b.readLine());
		   }
			catch(Exception e)
			{
				System.out.println("Invalid entry :Try valid numbers");
			}
			switch(c)
			{
			case 1:
				FileWriter w = new FileWriter("bok.txt",true);
				BufferedWriter bw = new BufferedWriter(w);
				System.out.println("Enter the book title");
				String tit = b.readLine();
				System.out.println("Enter the book author");
				String auth = b.readLine();
				System.out.println("Enter the publication");
				String pub = b.readLine();
				bw.write(tit+" ");
				bw.write(auth+" ");
				bw.write(pub);
				bw.close();
				bw.newLine();
				w.close();
				break;	
			case 2:
				FileReader fr = new FileReader("bok.txt");
				BufferedReader br = new BufferedReader(fr);
				String i = b.readLine();
				while(i!=null)
				{
					System.out.println(i);
					i = br.readLine();
				}
				br.close();
				break;
			case 3:
				System.out.println("Thank you for refering book");
				System.exit(0);
				
			
			}
		}

	}

}
