import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Travel extends Exception{

		
		public static void RouteNotFoundException()
		     {
		      System.out.println("Your source and destination is not matching . For your information this flight will move from delhi to Torento only");
		     }

		   public static void tour(String  s)throws Travel, NumberFormatException, IOException

		 {
		   String sourceplace = "India";
		   String destinationplace="Canada";
		   String  routingvia="Belgium";
		   double distance = 9899;
		   int p = 0;
		  
		  BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		   System.out.println("Enter your choice:");

		   p=Integer.parseInt(br.readLine());
		   switch(p)
		   {
		      case 1:
		      System.out.println("Enter the source place ");
		      String source = br.readLine();
		      System.out.println("Enter the Destination place");
		      String dest = br.readLine();
		      if(sourceplace.equalsIgnoreCase(source)&&  destinationplace.equalsIgnoreCase(dest))
		      {
		    	  System.out.println("Your source and destination is conected ,From Delhi(India) to Torento(Canada)");
		      }
		      else  
		      { 
		    	  Travel t =  new Travel();
		    	  throw t;
		      }  
		      break;
		      case 2:
		    	  System.out.println("Enter the source place ");
			      String source1 = br.readLine();
			      System.out.println("Enter the Destination place");
			      String dest1 = br.readLine();
			      
			      if(sourceplace.equalsIgnoreCase(source1)&&  destinationplace.equalsIgnoreCase(dest1))
			      {
			      System.out.println("The shortest distance to canada  is via belgium");
			      }
			      else
			      {
			    	  System.out.println("Sory this flight only from Delhi to Torento");
			      }
			      break;
		
		  
		      case 3:
		       System.out.println("The source place is " + sourceplace );
		       System.out.println("The destination palce is "+destinationplace);
		       System.out.println("The routing is via "+routingvia);
		       System.out.println("The total distance is "+distance+"km");
		       break;
		      case 4:
		    	  System.out.println("Thank you for using our service");
		    	  System.out.println("Greetings from India New Airlines");
		    	 System.exit(0);
		   }
		   }
		  }
		    
		    


