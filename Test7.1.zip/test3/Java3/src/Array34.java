
public class Array34 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		int arr[] = {8,1,5,7,2};
		int counter = 0;
		for(int i =0;i<arr.length;i++)
		{
			if(arr[i]==1)
			{
				counter++;
			}
	}
	}
}


