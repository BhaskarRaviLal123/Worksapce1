
public class TestStar {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s="Rahul";
		for(int i=0;i<s.length();i++)
		{
			System.out.print("*");
		}
	}

}
