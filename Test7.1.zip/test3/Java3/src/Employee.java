import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class Employee {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
	
				InputStreamReader i = new InputStreamReader(System.in);
				BufferedReader r = new BufferedReader(i);
		        int one =0;
		        while(true)
		        {
		            System.out.println("1:Add employee");
		            System.out.println("2:View all employee details");
		            System.out.println("3:View employee first name");
		            System.out.println("4:Exist");
		        try {
		                one=Integer.parseInt(r.readLine());
		            } 
		            catch (NumberFormatException ie)
		            {
		                System.out.println("This type of input will not consider,Try option numbers");
		            }
		            switch(one)
		            {
		            case 1:
		                    
		                    FileWriter fw=new FileWriter("emp.txt",true);
		                    BufferedWriter bq=new BufferedWriter(fw);
		                    System.out.println("Enter the Employee id: ");
		                    String id=r.readLine();
		                    System.out.println("Enter Employee First name:");
		                    String fname = r.readLine();
		                    System.out.println("Enter Employee Last name:");
		                    String lname = r.readLine();
		                    System.out.println("Enter Employee Salary:");
		                    String sal = r.readLine();
		                    bq.write(id+" ");
		                    bq.write(fname+" ");
		                    bq.write(lname+" ");
		                    bq.write(sal);
		                    bq.newLine();
		                    bq.close();
		                    fw.close();
		                    break;
		            case 2:
		                    FileReader wf=new FileReader("emp.txt");
		                    BufferedReader bb=new BufferedReader(wf);
		                    String empr=bb.readLine();
		                    while(empr!=null)
		                    {
		                        System.out.println(empr);
		                        empr=bb.readLine();
		  
		                    } 
		                    wf.close();
		                    break;
		            case 3: 
		            	  
		            	   FileReader fw1=new FileReader("emp.txt");
		                   BufferedReader bb1=new BufferedReader(fw1);
		                   System.out.println("Enter the last name ");
		                   String empr1 = r.readLine();
		                   String line = bb1.readLine();
		                   while(line!=null)
		                   {
		                	   
		                	    String arr[] = line.split(" ");
		                	    
		                	    if(arr[2].equalsIgnoreCase(empr1))
		                	    		{
		          
		                	        	System.out.println(arr[1]);
		                	        	line= bb1.readLine(); 
		  		                	//   
		                	    	}
		                	    line= bb1.readLine();
		                	    }
		                  
		                     fw1.close();
		                   
		                  
		                   break;
		            
		            case 4:
		                    System.out.println("Thank you for usimg this ");
		                    System.exit(0);
		                    default:
		                    System.out.println("Enter valid details");
		            }
		        }
	}
}

		

	


