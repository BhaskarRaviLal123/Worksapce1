import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class TestFlight {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		  
		 InputStreamReader in=new InputStreamReader(System.in);

		  BufferedReader bre=new BufferedReader(in);
		  while(true){
		  System.out.println("1:Make your travel");
		  System.out.println("2:Find the shortest route ");
		  System.out.println("3:Plan your trip");
		  System.out.println("4:Exit");
		  
		  try{
			  String t = null;
			  Travel.tour(t);
		  }
		  catch(Travel ty)
		  {
			  Travel.RouteNotFoundException();
		  }
		  }
	}

}
