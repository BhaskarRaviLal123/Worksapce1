package com.ust_global;
import javax.ejb.Remote;

@Remote
public interface MyuserBeanRemote {
	public boolean validateuser(String Username,String UserPassword);
	public void addUser(Myuser s);
	

}
