package com.ust_global;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="Myuser")
public class Myuser implements Serializable {
		
		 private String Username;
	     private String UserPassword;
	     
	     @Id
	  	@Column(name="USERNAME")
		public String getUsername() {
			return Username;
		}
		public void setUsername(String username) {
			Username = username;
		}
		public String getUserPassword() {
			return UserPassword;
		}
		public void setUserPassword(String userPassword) {
			UserPassword = userPassword;
		}
		
		public Myuser()
		{
			
		}
	}