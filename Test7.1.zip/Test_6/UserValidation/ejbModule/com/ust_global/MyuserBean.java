package com.ust_global;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class MyuserBean
 */
@Stateless
public class MyuserBean implements MyuserBeanRemote {

    /**
     * Default constructor. 
     */
	@PersistenceContext(name="MyuserUnit")
	EntityManager entityManager;
    public MyuserBean() {
        // TODO Auto-generated constructor stub
    }
    
	@Override
	public boolean validateuser(String Username, String UserPassword) {
		Myuser s=null;
		boolean found =false;
		System.out.println("1 "+Username+" and  "+UserPassword);
		s = entityManager.find(Myuser.class,Username);
		entityManager.flush();
		if (s!=null)
		{
		if(s.getUsername().equals(Username) && s.getUserPassword().equals(UserPassword))
		   found = true;
		}
		s=null;   
		System.out.println("2 going to return "+found);
		//System.out.println("3 "+s.getUsername()+"..."+s.getUserPassword());
		return found;
	}

	@Override
	public void addUser(Myuser s) {
			entityManager.persist(s);
		
	}

}
