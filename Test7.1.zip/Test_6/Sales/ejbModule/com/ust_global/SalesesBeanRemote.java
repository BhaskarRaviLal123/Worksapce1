package com.ust_global;
import javax.ejb.Remote;
import java.util.List;
@Remote
public interface SalesesBeanRemote {
		public void addSaleses(Saleses s);
		public Saleses readSaleses(int id);
		public List<Saleses> readAllSaleses();
	    public Saleses updateSaleses(int id,String date,int amount,String city);
	    public Saleses deleteSaleses(int id);
	}


