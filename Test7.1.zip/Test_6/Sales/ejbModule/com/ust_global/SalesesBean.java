package com.ust_global;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class SalesesBean
 */
@Stateless

public class SalesesBean implements SalesesBeanRemote {

	@PersistenceContext(name="SalesesUnit")
	EntityManager entityManager;
    public SalesesBean() {
       
    }

	@Override
	public void addSaleses(Saleses s) {
		entityManager.persist(s);
		
	}

	@Override
	public Saleses readSaleses(int id) {
		Saleses sbr = entityManager.find(Saleses.class, id);
		return sbr;
	}

	@Override
	public List<Saleses> readAllSaleses() {
			List<Saleses> allSaleses=entityManager.createQuery("FROM Saleses").getResultList();
			return allSaleses;
	
	}

	@Override
	public Saleses updateSaleses(int id, String date,int amount,String city) {
		Saleses sbr =entityManager.find(Saleses .class, id);
		if(sbr!=null)
		{
			sbr.setSalesDate(date);
		sbr.setSalesAmount(amount);
			sbr.setSalesCity(city);
			entityManager.merge(sbr);
		}
		else
		{
			sbr=null;
		}
		
		return sbr;
	}
	@Override
	public Saleses deleteSaleses(int id) {
		Saleses sbr =entityManager.find(Saleses.class, id);
		if(sbr!=null)
		{
			entityManager.remove(sbr);
		}
		else
		{
			sbr = null;
		}
		return sbr;
	}
	}


