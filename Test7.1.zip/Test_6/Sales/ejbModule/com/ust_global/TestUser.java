package com.ust_global;

import javax.naming.NamingException;

public class TestUser {
	public static void main(String[] args)throws NamingException{

}
}