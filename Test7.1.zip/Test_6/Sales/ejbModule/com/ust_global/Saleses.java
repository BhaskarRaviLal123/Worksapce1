package com.ust_global;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="Saleses")
public class Saleses implements Serializable {
     private int SalesId;
     private String SalesDate;
   private int SalesAmount;
     private String SalesCity;
     @Id
 	@Column(name="SALESID")
	public int getSalesId() {
		return SalesId;
	}
	public void setSalesId(int salesId) {
		SalesId = salesId;
	}
	public String getSalesDate() {
		return SalesDate;
	}
	public void setSalesDate(String salesDate) {
		SalesDate = salesDate;
	}
public int getSalesAmount() {
	return SalesAmount;
}
public void setSalesAmount(int salesAmount) {
		SalesAmount = salesAmount;
	}
	public String getSalesCity() {
		return SalesCity;
	}
	public void setSalesCity(String salesCity) {
		SalesCity = salesCity;
	}
     
}