package com.ust_global;

import java.util.Properties;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.http.HttpSession;

public class LoginBean {
	String name;
	String password;
	String msg ="";
	
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public LoginBean()
	{
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String login() throws NamingException
	{
		
		//if(this.name.equals(this.password))
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx= new InitialContext(p);
		MyuserBeanRemote m =(MyuserBeanRemote)ctx.lookup("MyuserBean/remote");
		if(m.validateuser(this.name,this.password))
		
		{
			msg="Home";
			FacesContext f = FacesContext.getCurrentInstance();
			ExternalContext ec =f.getExternalContext();
			HttpSession session=(HttpSession)ec.getSession(false);
			session.setAttribute("name",this.name);
		}
		else
		{
			msg="Failure";
		}
		System.out.println("Returning msg");
		return msg;
	}
	public String logout()
	{
		System.out.println("reaching logout");
		FacesContext f = FacesContext.getCurrentInstance();
		ExternalContext ec =f.getExternalContext();
		HttpSession session=(HttpSession)ec.getSession(false);
		String msg="";
		if(session!=null)
		{
			System.out.println("session is found");
			String x=(String)session.getAttribute("name");
			if(x!=null)
			{
				System.out.println("name is found");
				System.out.println("We are sucessfully goint to logout");
				session.removeAttribute(name);
				session.invalidate();
				msg="Login";
			}
		}
		System.out.println("returning "+msg);
		return msg;
	}
		public String Signup() throws NamingException
		{
			Properties p=new Properties();
			p.put(Context.PROVIDER_URL, "localhost:1099");
			p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
			p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
			Context ctx= new InitialContext(p);
			MyuserBeanRemote m =(MyuserBeanRemote)ctx.lookup("MyuserBean/remote");
			Myuser ms=new Myuser();
			ms.setUsername(name);
			ms.setUserPassword(password);
			m.addUser(ms);
			
		{
			msg="Home";
			FacesContext f = FacesContext.getCurrentInstance();
			ExternalContext ec =f.getExternalContext();
			HttpSession session=(HttpSession)ec.getSession(false);
			session.setAttribute("name",this.name);
			}
			return msg;
		}
	
			
		}
	

