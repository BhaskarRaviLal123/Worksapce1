package com.ust_global;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ClientSalesServelet
 */
public class ClientSalesServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClientSalesServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id=(request.getParameter("SalesId"));
		String date1=request.getParameter("Salesdate");
		String amt=request.getParameter("Salesamt");
		String city1 = request.getParameter("salescity1");
		PrintWriter pw=response.getWriter();
		System.out.println("id received is "+id);
		System.out.println("date received is "+date1);
	     System.out.println("amount received is "+amt);
		System.out.println("amount received is "+city1);
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx=null;
		SalesesBeanRemote  sbr=null;
		try {
		ctx = new InitialContext(p);
		} catch (NamingException e) {
		e.printStackTrace();
		}
		try {
		sbr=(SalesesBeanRemote) ctx.lookup("SalesesBean/remote");
		} catch (NamingException e) {
		e.printStackTrace();
		}
		Saleses s= new Saleses();
		String val=request.getParameter("a");
		choice c=choice.valueOf(val);
		switch(c)
		{
		case add: {
			int id1=Integer.parseInt(id);
			int amt1=Integer.parseInt(amt);
			s.setSalesId(id1);
			s.setSalesDate(date1);
            s.setSalesAmount(amt1);
			s.setSalesCity(city1);
			sbr.addSaleses(s);
			pw.println("</p>"+"Successfully inserted"+"</p>");
			pw.println("<p>");
			pw.println("<A HREF= \"http://localhost:8082/SalesServelet/SalesDetails.html\">Back to Options</A>");
			pw.println("</p>");
			}
			break;
		case update:
		{
		
			int id1=Integer.parseInt(id);
			int amt1=Integer.parseInt(amt);
//			s.setSalesId(id1);
//			s.setSalesDate(date1);
//			s.setSalesAmount(amt1);
//		    s.setSalesCity(city1);
			Saleses st = sbr.updateSaleses(id1,date1,amt1,city1);
			if(st!=null)
			{
			pw.println("<p>"+"Successfully updated into database!"+"</p>");
			//pw.println(st.getSalesId()+""+st.getStudentName());
			pw.println("<p>");
			pw.println("<A HREF= \"http://localhost:8082/SalesServelet/SalesDetails.html\">Back to Options</A>");
			pw.println("</p>");
			}
			else
			{
				
				pw.println("<p>"+"Update Faild!"+"</p>");
			
				pw.println("<p>");
				pw.println("<A HREF= \"http://localhost:8082/SalesServelet/SalesDetails.html\">Back to Options</A>");
				pw.println("</p>");
			}
			break;
			
			}
		case read:
		{
			List allSaleses=sbr.readAllSaleses();
			for (int i = 0; i < allSaleses.size(); i++) {
				if(id=="")
				{
					Saleses st=(Saleses)allSaleses.get(i);
					
					pw.println("<p>"+st.getSalesId()+":"+st.getSalesDate()+":"+st.getSalesAmount()+":"+st.getSalesCity()+"</p>");
					
				}
		}
			pw.println("<p>");
			pw.println("<A HREF= \"http://localhost:8082/SalesServelet/SalesDetails.html\">Back to Options</A>");
			pw.println("</p>");
			break;
		}
		case delete:
		{
			int id1=Integer.parseInt(id);
			s.setSalesId(id1);
			Saleses st=sbr.readSaleses(id1);
			if(st!=null)
			{
				Saleses s1=sbr.deleteSaleses(id1);
				pw.println("<p>"+"Successfully deleted!"+"</p>");
			}
			
			else
			{
				pw.println("<p>"+"Such id is not there in the databas"+"</p>");
			}
			pw.println("<p>");
			pw.println("<A HREF= \"http://localhost:8082/SalesServelet/SalesDetails.html\">Back to Options</A>");
			pw.println("</p>");
			break;
		}
		case search:
		{
		  int id1=Integer.parseInt(id);
		   s.setSalesId(id1);
			Saleses st=sbr.readSaleses(id1);
			if(st!=null)
			{
			pw.println("<p>"+"The Id is found in the database"+"</p>");
			pw.println(st.getSalesId());
	        }
			else
			{ 
			pw.println("<p>"+"The Sales ID is NOT found in the record!"+"</p>");
			}	
			pw.println("<p>");
			pw.println("<A HREF= \"http://localhost:8082/SalesServelet/SalesDetails.html\">Back to Options</A>");
			pw.println("</p>");
			break;
		}
			default:pw.println("Some thing went wrong go to options");
			break; 
	}
		
	}
	
	public enum choice
	{
		add,
		update,
		read,
		delete,
		search
		}
	
}

		
		
		