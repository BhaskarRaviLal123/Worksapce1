package com.ust_global;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class MyEmployeeBean {

	private int employeid;
	private String employename;
	private int employemanager;
	String msg;
	String choose;
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getChoose() {
		return choose;
	}
	public void setChoose(String choose) {
		this.choose = choose;
	}
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	String input;
	public MyEmployeeBean()
	{
		
	}
	public int getEmployeid() {
		return employeid;
	}
	public void setEmployeid(int employeid) {
		this.employeid = employeid;
	}
	public String getEmployename() {
		return employename;
	}
	public void setEmployename(String employename) {
		this.employename = employename;
	}
	public int getEmployemanager() {
		return employemanager;
	}
	public void setEmployemanager(int employemanager) {
		this.employemanager = employemanager;
	}
	public List<MyEmployee> getSearchEmployeeByManager() {
		return searchEmployeeByManager;
	}
	public void setSearchEmployeeByManager(List<MyEmployee> searchEmployeeByManager) {
		this.searchEmployeeByManager = searchEmployeeByManager;
	}
	List<MyEmployee> searchEmployeeByManager=new ArrayList<MyEmployee>();
	List<MyEmployee> searchEmployeename=new ArrayList<MyEmployee>();
	
	public List<MyEmployee> getSearchEmployeename() {
		return searchEmployeename;
	}
	public void setSearchEmployeename(List<MyEmployee> searchEmployeename) {
		this.searchEmployeename = searchEmployeename;
	}
	public String searchEmploye() throws NamingException
	{
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		MyEmployeeBeanRemote empremote=(MyEmployeeBeanRemote)ctx.lookup("MyEmployeeBean/remote");
		if(choose.equalsIgnoreCase("manager"))
		{
			searchEmployeeByManager=empremote.searchByManager(this.input);
		if(!searchEmployeeByManager.isEmpty())
			msg="searchEmployeeByManager";
		else
			msg="failed";
		}
		else if(choose.equalsIgnoreCase("Employe"))
		{
			searchEmployeename=empremote.searchByName(this.input);
			if(!searchEmployeename.isEmpty())
				msg="searchEmployeename";
			else
				msg="failed";
		}
		
		return msg;
	}
	}
	

	
	

	