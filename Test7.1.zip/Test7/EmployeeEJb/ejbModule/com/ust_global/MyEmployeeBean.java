package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class MyEmployeeBean
 */
@Stateless
public class MyEmployeeBean implements MyEmployeeBeanRemote {

    /**
     * Default constructor. 
     */
	@PersistenceContext(name="MyEmployeeUnit")
	EntityManager entityManager;
    public MyEmployeeBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public List<MyEmployee>searchByManager(String Manager) {
		List<MyEmployee> allEmp=entityManager.createQuery("From MyEmployee").getResultList();
		List<MyEmployee> search = new ArrayList();
		if(allEmp!=null)
		{
		for(MyEmployee employee:allEmp) 
		{
				if(employee.getEMPLOYEEMANAGER().equalsIgnoreCase(Manager))
				{
					search.add(employee);
				}
		}
		}
		return search;
}

	@Override
	public List<MyEmployee> searchByName(String ename) {
		List<MyEmployee> allemp=entityManager.createQuery("From MyEmployee").getResultList();
		List<MyEmployee> searchResult = new ArrayList();
		if(allemp!=null)
		{
		for (MyEmployee employee:allemp) 
		{
				if(employee.getEMPLOYEENAME().equalsIgnoreCase(ename))
				{
					searchResult.add(employee);
				}
		}
		}
		return searchResult;
}

	}






