package com.ust_global;

import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class TestEmployee {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		// TODO Auto-generated method stub
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx= new InitialContext(p);
		 MyEmployeeBeanRemote m =(MyEmployeeBeanRemote)ctx.lookup("MyEmployeeBean/remote");
		 MyEmployee ms=new  MyEmployee();
//		
		String employee = "Arun";

		List< MyEmployee> employ=m.searchByManager(employee);
		if(!employ.isEmpty())
		{
			for (int i = 0; i <employ.size() ; i++) 
			{
				System.out.println(employ.get(i).getEMPLOYEEID()+" "+employ.get(i).getEMPLOYEENAME());//getEMPLOYEEID());//+" "+book.get(i).getBOOKAUTHOR()+" "+book.get(i).getBOOKNAME());
			}
		}
		else
			System.out.println("result is null");
		
		
		
	}

	}


