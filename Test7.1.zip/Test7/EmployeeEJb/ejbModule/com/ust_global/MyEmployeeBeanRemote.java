package com.ust_global;
import java.util.List;

import javax.ejb.Remote;

@Remote
public interface MyEmployeeBeanRemote {
		public List<MyEmployee>searchByManager(String Manager); 
		public List<MyEmployee> searchByName(String ename);
		
	}

