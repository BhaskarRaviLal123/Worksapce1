package com.ust_global;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="MyEmployee")
public class MyEmployee implements Serializable{
	private int EMPLOYEEID;
	private String EMPLOYEENAME;
	private String EMPLOYEEMANAGER;
	
	public MyEmployee()
	{
		
	}
	 @Id
	@Column(name="EMPLOYEEID")
	public int getEMPLOYEEID() {
		return EMPLOYEEID;
	}
	public void setEMPLOYEEID(int eMPLOYEEID) {
		EMPLOYEEID = eMPLOYEEID;
	}
	public String getEMPLOYEENAME() {
		return EMPLOYEENAME;
	}
	public void setEMPLOYEENAME(String eMPLOYEENAME) {
		EMPLOYEENAME = eMPLOYEENAME;
	}
	public String getEMPLOYEEMANAGER() {
		return EMPLOYEEMANAGER;
	}
	public void setEMPLOYEEMANAGER(String eMPLOYEEMANAGER) {
		EMPLOYEEMANAGER = eMPLOYEEMANAGER;
	}

}
