package com.ust_global;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class BooksBean
{
	private String bookName;
	private String bookAuthor;
	private String bookId;
	String msg;
	String option;
	String input;

	
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	public String getOption() {
		return option;
	}
	public void setOption(String option) {
		this.option = option;
	}

	List<Books> searchBooksByAuthor=new ArrayList<Books>();
	public List<Books> getSearchBooksByAuthor() {
		return searchBooksByAuthor;
	}
	public void setSearchBooksByAuthor(List<Books> searchBooksByAuthor) {
		this.searchBooksByAuthor = searchBooksByAuthor;
	}
	public List<Books> getSearchBooksByBookName() {
		return searchBooksByBookName;
	}
	public void setSearchBooksByBookName(List<Books> searchBooksByBookName) {
		this.searchBooksByBookName = searchBooksByBookName;
	}
	public List<Books> getReadAllBooks() {
		return readAllBooks;
	}
	public void setReadAllBooks(List<Books> readAllBooks) {
		this.readAllBooks = readAllBooks;
	}
	public Books getSearchBooksByBookId() {
		return searchBooksByBookId;
	}
	public void setSearchBooksByBookId(Books searchBooksByBookId) {
		this.searchBooksByBookId = searchBooksByBookId;
	}
	public Books getUpdateBook() {
		return updateBook;
	}
	public void setUpdateBook(Books updateBook) {
		this.updateBook = updateBook;
	}

	List<Books> searchBooksByBookName=new ArrayList<Books>();
	List<Books> readAllBooks=new ArrayList<Books>();
	Books searchBooksByBookId=new Books();
	Books updateBook=new Books();




	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBookAuthor() {
		return bookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public BooksBean() {
		super();
	}
	
	public String addBook() throws NamingException
	{
		Books b=new Books();
		b.setBOOKNAME(bookName);
		b.setBOOKID(bookId);
		b.setBOOKAUTHOR(bookAuthor);
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		BooksBeanRemote booksRemote=(BooksBeanRemote) ctx.lookup("BooksBean/remote");
		
		if(booksRemote!=null)
		{
			booksRemote.addBook(b);
			msg="added";
		}
		else
			msg="failed";
		
		return msg;
	}
	
	public String deleteBook(String bookId) throws NamingException 
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		
		BooksBeanRemote booksRemote=(BooksBeanRemote) ctx.lookup("BooksBean/remote");
		
		if(booksRemote!=null)
		{
			booksRemote.deleteBook(bookId);
			msg="deleted";
		}
		else
			msg="failed";
		return msg;
	}
	
	public String searchBooks() throws NamingException
	{
		
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote booksRemote=(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		
		System.out.println(this.option);
		System.out.println(this.input);
		
		if(option.equalsIgnoreCase("author"))
		{
		searchBooksByAuthor=booksRemote.searchByAuthor(this.input);
		if(!searchBooksByAuthor.isEmpty())
			msg="searchBooksByAuthor";
		else
			msg="failed";
		}
		else if(option.equalsIgnoreCase("Book Name"))
		{
			searchBooksByBookName=booksRemote.searchByBookName(this.input);
			if(!searchBooksByBookName.isEmpty())
				msg="searchBooksByBookName";
			else
				msg="failed";
		}
		else if(option.equalsIgnoreCase("Book ID"))
		{
			searchBooksByBookId=booksRemote.readBook(this.input);
			if(searchBooksByBookId!=null)
				msg="searchBooksByBookId";
			else
				msg="failed";
		}
		return msg;
	}
	


	
	public String readBooksAll() throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote booksRemote=(BooksBeanRemote) ctx.lookup("BooksBean/remote");
		
		readAllBooks=booksRemote.readAllBook();
		if(readAllBooks!=null)
			msg="readAllBooks";
		else
			msg="failed";
		return msg;
	}
	
	public String updateBook(String bookId, String bookName, String bookAuthor) throws NamingException
	{
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL,"localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
		Context ctx=new InitialContext(p);
		BooksBeanRemote booksRemote=(BooksBeanRemote) ctx.lookup("BooksBean/remote");
		
		updateBook.setBOOKAUTHOR(bookAuthor);
		updateBook.setBOOKNAME(bookName);
		updateBook.setBOOKID(bookId);
		try
		{
		booksRemote.updateBook(bookId, bookName, bookAuthor);
		msg="updated";
		}
		catch(Exception e)
		{
			msg="failed";
		}
		return msg;
	}
}
