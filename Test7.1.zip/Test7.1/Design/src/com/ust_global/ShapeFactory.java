package com.ust_global;

public class ShapeFactory {
	public static Shape getshape(String x)
	{
	Shape s = null;
	if(x.equalsIgnoreCase("Cricle"))
	{
		s=  new Cricle();
	}
	if(x.equalsIgnoreCase("Triangle"))
	{
		s=  new Triangle();
	}
	if(x.equalsIgnoreCase("Square"))
	{
		s=  new Square();
	}
	return s;
	}
}
