package com.ust_global;
import java.util.Scanner;
public class NumberDivision {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		 
	        int num;
	        Scanner s = new Scanner(System.in);
	        System.out.print("Enter the number number to cheak whather it is divisible by 2:");
	        num = s.nextInt();
	        if(num % 2 == 0)
	        {
	            System.out.println(num+" is divisible by 2");
	        }
	        else
	        {
	            System.out.println(num+" is not divisible by 2");
	        }
	    }
	}

