package com.ust_global;

public class TestCommandPattern {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Tv lt = new Tv();
		RemoteControl rc=new RemoteControl();
		TvSwitchOn lton=new TvSwitchOn(lt);
		TvSwitchOff ltoff=new TvSwitchOff(lt);
		rc.setCommand(lton);
		rc.pressButton();
		rc.setCommand(ltoff);
		rc.pressButton();

		 

		}
	}

