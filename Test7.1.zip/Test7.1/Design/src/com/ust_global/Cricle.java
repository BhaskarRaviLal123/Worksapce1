package com.ust_global;

public class Cricle implements Shape{

	@Override
	public void draw() {
	System.out.println("Draw Circle");
		
	}

}
