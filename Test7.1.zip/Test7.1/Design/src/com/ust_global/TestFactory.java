package com.ust_global;

public class TestFactory {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Shape s = ShapeFactory.getshape("Cricle");
		s.draw();
		Shape s1 = ShapeFactory.getshape("Triangle");
		s1.draw();
		Shape s3 = ShapeFactory.getshape("Triangle");
		s3.draw();
	}

}
