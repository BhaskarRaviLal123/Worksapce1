package com.ust_global;

public class TestSingleton {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Singleton s = Singleton .getInstance();
		System.out.println(s.hashCode());
		Singleton s1=Singleton.getInstance();
		System.out.println(s1.hashCode());
		
	
			


	}

}
