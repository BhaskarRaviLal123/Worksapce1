package com.ust_global;

public class Triangle implements Shape {

	@Override
	public void draw() {
		System.out.println("Draw Traingle");	
	}

}
