package com.ust_global;

public class Number {
	int num;

	public Number()
	{
		
	}
	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

}
