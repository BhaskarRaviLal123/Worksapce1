package com.ust_global;

public class TvSwitchOn implements Command {
	Tv lt;
	public TvSwitchOn(Tv lt2) {
		// TODO Auto-generated constructor stub
	}



	public void switchOn(Tv lt) {

		// TODO Auto-generated constructor stub

		this.lt=lt;

		}

		 

		@Override

		public void execute() {

		// TODO Auto-generated method stub

		lt.switchOn();

		}

		 

		}