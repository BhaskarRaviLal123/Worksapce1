package com.ust_global;

public class TvSwitchOff implements Command{

	 

	Tv lt;

	 

	public TvSwitchOff(Tv lt2) {
		// TODO Auto-generated constructor stub
	}



	public void switchOff(Tv lt) {

	// TODO Auto-generated constructor stub

	this.lt=lt;

	}

	 

	@Override

	public void execute() {

	// TODO Auto-generated method stub

	lt.switchOff();

	}

	}

	 