package com.ust_global;

public class Tv {
	public void switchOn()
	{
		System.out.println("The Tv is swithed on");
	}
	
	public void switchOff()
	{
		System.out.println("The Tv is swithed off");
	}
	
}
