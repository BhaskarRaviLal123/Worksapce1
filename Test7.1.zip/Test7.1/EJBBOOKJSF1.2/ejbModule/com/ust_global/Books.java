package com.ust_global;
//not needed
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity(name="Books")
public class Books implements Serializable {
  private String BOOKID;
  private String BOOKNAME;
  private String BOOKAUTHOR;
 
  public Books()
  {
	  
  }
  @Id
	@Column(name="BOOKID")
public String getBOOKID() {
	return BOOKID;
}
public void setBOOKID(String bOOKID) {
	BOOKID = bOOKID;
}
public String getBOOKNAME() {
	return BOOKNAME;
}
public void setBOOKNAME(String bOOKNAME) {
	BOOKNAME = bOOKNAME;
}
public String getBOOKAUTHOR() {
	return BOOKAUTHOR;
}
public void setBOOKAUTHOR(String bOOKAUTHOR) {
	BOOKAUTHOR = bOOKAUTHOR;
}
  
}
