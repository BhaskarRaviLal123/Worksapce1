package com.ust_global;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Session Bean implementation class BooksBean
 */
@Stateless
public class BooksBean implements BooksBeanRemote {

    /**
     * Default constructor. 
     */

	@PersistenceContext(name="BooksUnit")
	
	
	
	
	
	EntityManager entityManager;
 
	
    public BooksBean() {
        // TODO Auto-generated constructor stub
    }
//not needed
	@Override
	public void addBook(Books s) {
		entityManager.persist(s);
	}

	@Override
	public Books readBook(String id) {
		Books sbr = entityManager.find(Books.class, id);
		return sbr;

	}

	@Override
	public List<Books> readAllBook() {
		List<Books> allbooks=entityManager.createQuery("FROM Books").getResultList();
		return allbooks;
	}

	@Override
	public Books updateBook(String id, String bname, String author) {
		 Books sbr =entityManager.find(Books.class, id);
		if(sbr!=null)
		{
			sbr.setBOOKNAME(bname);
			sbr.setBOOKAUTHOR(author);
			entityManager.merge(sbr);
		}
		else
		{
			sbr=null;
		}
		
		return sbr;

	}

	@Override
	public Books deleteBook(String id) {
		Books sbr =entityManager.find(Books.class, id);
		if(sbr!=null)
		{
			entityManager.remove(sbr);
		}
		else
		{
			sbr = null;
		}
		return sbr;

	}

	@Override
	public List<Books> searchByAuthor(String author) {
		List<Books> allBooks=entityManager.createQuery("From Books").getResultList();
		List<Books> searchResult = new ArrayList();
		if(allBooks!=null)
		{
		for (Books books:allBooks) 
		{
				if(books.getBOOKAUTHOR().equalsIgnoreCase(author))
				{
			
					searchResult.add(books);
				}
		}
		}
		return searchResult;
	}

	@Override
	public List<Books> searchByBookName(String bname) {
		
		
			List<Books> allBooks=entityManager.createQuery("From Books").getResultList();
			List<Books> searchResult = new ArrayList();
			if(allBooks!=null)
			{
			for (Books books:allBooks) 
			{
					if(books.getBOOKNAME().equalsIgnoreCase(bname))
					{
						searchResult.add(books);
					}
				
			}
			}
			return searchResult;
	}
	}
	

