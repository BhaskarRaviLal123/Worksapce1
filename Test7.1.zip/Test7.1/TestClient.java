package com.ust_global;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class TestClient {

	/**
	 * @param args
	 * @throws NamingException 
	 */
	public static void main(String[] args) throws NamingException {
		Properties p=new Properties();
		p.put(Context.PROVIDER_URL, "localhost:1099");
		p.put(Context.INITIAL_CONTEXT_FACTORY, "org.jnp.interfaces.NamingContextFactory");
		p.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces");
		Context ctx= new InitialContext(p);
		BooksBeanRemote m =(BooksBeanRemote)ctx.lookup("BooksBean/remote");
		Books ms=new Books();
//	   String id1 = "a1";
//	   String bnames = "Alcmist";
//	   String bauth = "Paulo Coelho";
//	   ms.setBOOKID(id1);
//	   ms.setBOOKNAME(bnames);
//	   ms.setBOOKAUTHOR(bauth);
//	  m.addBook(ms);
//		
		String bname = "Alcmist";

		List<Books> book=m.searchByBookName(bname);
		if(book!=null)
		{
			for (int i = 0; i < book.size(); i++) 
			{
				System.out.println(book.get(i).getBOOKID()+" "+book.get(i).getBOOKAUTHOR()+" "+book.get(i).getBOOKNAME());
			}
		}
		else
			System.out.println("result is null");
		
		
		
	}

	}


