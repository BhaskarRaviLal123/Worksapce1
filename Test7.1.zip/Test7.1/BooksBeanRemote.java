package com.ust_global;
import javax.ejb.Remote;
import java.util.List;
@Remote
public interface BooksBeanRemote {
		public void addBook(Books s);
		public Books readBook(String id);
		public List<Books> searchByAuthor(String author); 
		public List<Books> searchByBookName(String bname);
		public List<Books> readAllBook();
	    public Books updateBook(String id,String bname,String author);
	    public Books deleteBook(String id);
	}