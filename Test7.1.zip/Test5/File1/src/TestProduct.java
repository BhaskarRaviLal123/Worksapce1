import java.io.*;
import java.util.*;
public class TestProduct {

	/**
	 * @param args
	 */
		// TODO Auto-generated method stub
		public static void main(String[] args) throws IOException 
		{
			InputStreamReader inputreader=new InputStreamReader(System.in);
			BufferedReader bufReader=new BufferedReader(inputreader);
			
			RandomAccessFile file=new RandomAccessFile("D:\\Test5\\File1\\Sales.txt","rw");
			HashMap product=new HashMap();
			file.seek(0);
			while(true)
			{
				String line=file.readLine();
				for(int i=0;line!=null;i++)
				{					
					String[] reader=line.split(",");
					RegionDetails region =new RegionDetails(reader[0], reader[1], reader[2],reader[3]);
					product.put(i, region);
					line=file.readLine();
				}
				line=file.readLine();
				break;
			}
			int choice = 0;
			while(true)
			{
				try
				{
					System.out.println("Choose the option");
					System.out.println("1.print all sales details");
					System.out.println("2.Total sales in each product");
					System.out.println("3.Aggregate sales of each regions");
					System.out.println("4.Products which sold most regionally");
					System.out.println("5.Product which sold most nationally");
					System.out.println("6.exit");
					choice=Integer.parseInt(bufReader.readLine());
				}
				catch (NumberFormatException e) 
				{
					System.out.println("please enter the numbers to go to options ");
				}
				switch (choice) 
				{
				case 1:
				{
					Set keys=product.keySet();
					Iterator it=keys.iterator();
					while(it.hasNext())
					{
						int key=(Integer) it.next();
						RegionDetails rg=(RegionDetails)product.get(key);
						rg.pritProductDetails();
					}
					break;
				}
				case 2:
					   
				case 6:
				{
					System.out.println("Thank you ");
					System.exit(0);
				}
				default:
					System.out.println("Please enter a valid option");
					break;
					
				}
				}

	}
		}


