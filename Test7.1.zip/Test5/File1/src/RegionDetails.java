
public class RegionDetails {
	String salesid;
	String date;
	String product;
	String price;
	public RegionDetails(String salesid, String date, String product,
			String price) {
		super();
		this.salesid = salesid;
		this.date = date;
		this.product = product;
		this.price = price;
	}
	public void pritProductDetails()
	{
		System.out.println(salesid);
		System.out.println(date);
		System.out.println(product);
		System.out.println(price);
	}
}


