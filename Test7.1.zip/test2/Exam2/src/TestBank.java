
public class TestBank {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NetBanking n = new NetBanking();
		n.discount();
		DebitCard d = new DebitCard();
		d.discount();
		CreditCard c =new CreditCard();
		c.discount();
	}

}
