
public class TestProject {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Java j = new Java();
		j.Client="UST GLOBAL ";
		j.proid = "Java";
		System.out.println(j.Client);
		System.out.println(j.proid);
		j.database();
		System.out.println("*************************************");
		
		Cplus c = new Cplus();
		c.Client = "Wipro";
		c.proid = "c++";
		System.out.println(c.Client);
		System.out.println(c.proid);
		c.database();
		System.out.println("**************************************");
		MainFrame m = new MainFrame();
		m.Client = "Tcs";
		m.proid = "Main Frame";
		System.out.println(m.Client);
		System.out.println(m.proid);
		m.database();
	}

}
