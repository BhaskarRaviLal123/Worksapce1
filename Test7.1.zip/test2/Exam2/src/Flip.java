
interface Flip {
	public void discount();
	

}
