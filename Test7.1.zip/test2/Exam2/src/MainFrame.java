
public class MainFrame extends Gipro{
	public static void database()
	{
		System.out.println("Main frame uses DB2 database");
	}
}
