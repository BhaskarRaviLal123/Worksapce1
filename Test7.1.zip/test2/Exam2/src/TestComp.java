
public class TestComp {

	/**
	 * @param args
	 */
	public static void calculateDiscount(Laptop l)
	{
		System.out.println("The name of the brand is :" +l.brandname);
		System.out.println("The price for one Laptop is :" +l.price);
		System.out.println("The number of laptops that you have buyed :" +l.qty);
		System.out.println("The discount for the item is :"+l.discount);
		System.out.println("The amount to be paid after discount:" +l.netprice);
	}
	public static void calculateDiscount(Desktop d)
	{
		System.out.println("The name of the brand is :" +d.brandname);
		System.out.println("The price for one Laptop is :" +d.price);
		System.out.println("The number of laptops that you have buyed :" +d.qty);
		System.out.println("The discount for the item is :"+d.discount);
		System.out.println("The amount to be paid after discount:" +d.netprice);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Laptop l =new Laptop();
		calculateDiscount(l);
		System.out.println("**************************************");
		Desktop d =new Desktop();
		calculateDiscount(d);
		

	}

}
