
abstract class Gipro {
	
	String proid;
	String Client;
	
}
