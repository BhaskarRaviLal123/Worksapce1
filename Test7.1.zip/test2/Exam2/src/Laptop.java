
public class Laptop {
	String brandname = "Laptop";
	double price = 20000;
	double qty = 2;
	double calculatedprice = price * qty;
	double discount = calculatedprice *(10/100);
	double netprice = calculatedprice - discount;
}
