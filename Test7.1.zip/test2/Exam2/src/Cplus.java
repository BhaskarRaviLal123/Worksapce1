
public class Cplus extends Gipro {
	public static void database()
	{
		System.out.println("c++ uses mysql databse");
	}

}
