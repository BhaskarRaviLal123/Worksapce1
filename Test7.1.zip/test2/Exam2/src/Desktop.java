
public class Desktop {
	String brandname = "Desktop";
	double price = 25000;
	double qty = 3;
	double calculatedprice = price * qty;
	double discount = calculatedprice *  0.25;;
	double netprice = calculatedprice- discount;

}
