
public class NetBanking implements Flip{

	@Override
	public void discount() {
		// TODO Auto-generated method stub
		System.out.println("You will get a discount of 5% by using netbanking");
	}
	


}
