
public class Java extends Gipro{
	String database="ORACLE";
	
}
