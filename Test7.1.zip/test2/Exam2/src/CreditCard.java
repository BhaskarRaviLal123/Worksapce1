
public class CreditCard implements Flip{

	@Override
	public void discount() {
		// TODO Auto-generated method stub
		System.out.println("You will get a discount of 2% for using Credit card");
	}
	

}
