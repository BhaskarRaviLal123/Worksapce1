
public class Series {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a  = 2;
		int b = 1;
		System.out.println("The series is printed as followes :");
		for(int i = 1;i<=6;i++)
		{
			a = a * i;
			b = b + 1;
			
			System.out.println(a);
		}
		System.out.println("The 10th number in the series is ");
		System.out.println(a);
		
	}
}