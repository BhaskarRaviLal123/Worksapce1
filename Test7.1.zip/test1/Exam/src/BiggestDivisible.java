
public class BiggestDivisible {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array[] = {9, 20, 60, 70, 90, 22, 45, 67, 89, 99,112,169,333};
		int max = 0;
		
		for(int i = 0;i<array.length;i++)
		{
			if(array[i]%3==0 && array[i]>max)
			{
				max = array[i];
				           
			}
			
		}
		System.out.println("The biggest number divisible by three is " +max);

	}

}
