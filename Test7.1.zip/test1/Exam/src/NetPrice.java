
public class NetPrice {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double price = 10000;
			int qty = 5;
		double discount = 0;
		double netprice = 0;
		 double	productprice =	price * qty;
		System.out.println("The price of the product is :" + price);
		System.out.println("The quantity is : " +qty);
		System.out.println("The actual product price is :" + productprice);
		if(productprice>=5000)
		{
			discount = productprice*0.05;
			netprice = productprice - discount;
			System.out.println("The discont for the product :" +discount);
			System.out.println("The actual amount  to pay after discount is  (Net price is ) :" +netprice);
			
		}
		else
		{
			System.out.println("No discount for the product");
		}

	} 

}
